"alpha" <- 0
"beta" <- 0
"tau" <- 1
