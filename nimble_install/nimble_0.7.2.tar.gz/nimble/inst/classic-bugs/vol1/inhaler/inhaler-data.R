"N" <-
286
"T" <-
2
"G" <-
2
"Npattern" <-
16
"Ncut" <-
3
"pattern" <-
structure(c(1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 1, 
2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4), .Dim = as.integer(c(16, 
2)))
"Ncum" <-
structure(c(59, 157, 173, 175, 186, 253, 270, 271, 271, 278, 
280, 281, 282, 285, 285, 286, 122, 170, 173, 175, 226, 268, 270, 
271, 278, 280, 281, 281, 284, 285, 286, 286), .Dim = as.integer(c(16, 
2)))
"treat" <-
structure(c(1, -1, -1, 1), .Dim = as.integer(c(2, 2)))
"period" <-
structure(c(1, 1, -1, -1), .Dim = as.integer(c(2, 2)))
"carry" <-
structure(c(0, 0, -1, 1), .Dim = as.integer(c(2, 2)))
