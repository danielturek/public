"beta" <-
0
"pi" <-
0
"kappa" <-
0
"a0" <-
c(2, 3, 4)
"tau" <-
1
