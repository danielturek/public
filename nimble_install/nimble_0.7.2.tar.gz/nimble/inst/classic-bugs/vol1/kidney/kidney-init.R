"t" <-
structure(c(NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, 
150, NA, NA, NA, NA, 23, NA, NA, NA, NA, NA, NA, 114, NA, NA, 
NA, NA, NA, 6, NA, NA, NA, 55, 7, NA, NA, 14, NA, NA, NA, NA, 
NA, NA, NA, NA, NA, 9, NA, 71, 26, 5, NA, NA, 160, 109, NA, 25, 
NA, 47, NA, NA, NA, NA, NA, NA, NA, NA, NA, 6, NA, 17, NA, 9), .Dim = as.integer(c(38, 
2)))
"beta.age" <- 0
"beta.sex" <- 0
"beta.disease" <- c(NA,0,0,0)
"alpha" <- -4.5
"r" <- 1.2
"tau" <- 10000
