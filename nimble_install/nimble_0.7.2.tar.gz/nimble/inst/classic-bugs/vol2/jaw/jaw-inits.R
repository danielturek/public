"beta0" <-
40
"beta1" <-
0
"beta2" <-
0
