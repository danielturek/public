"beta0" <-
0
"beta" <-
0
"q" <-
0.5
"phi" <-
structure(c(0.5, 0.5, 0.5, 0.5), .Dim = as.integer(c(2, 2)))
