"alpha" <-
0.6
"beta" <-
c(-0.45, -1)
"tau" <-
5
"k" <-
8
