#' nimble
#'
#' @name nimble
#' @docType package
NULL
